<html>
<head>
<title>Parque de la ciencia</title>
<meta charset="UTF-8">
</head>
<style>
    body {
      font-family: Arial, sans-serif;
      background-color: #000;
      color: white;
      text-align: center;
      padding: 40px 20px;
    }

    h1 {
      font-size: 3.5em;
    }
</style>
</head>
<h1>Parque de la ciencia</h1>
</center>
<p>
Se trata del sexto parque de este tipo que es inaugurado
 en la entidad mexiquense, el cual a partir de ahora será 
punto de reunión para las familias de esta zona 
oriente de la entidad mexiquense.
</p>
<p>
¿Con qué cuenta el Parque de la Ciencia de Los Reyes La Paz?
</p>
<p>
•	Mirador
</p>
<p> 
•	Área de juegos infantiles
</p>
<p>
•	Fuente danzante
</p>
<p>
•	Pista de Go Karts
</p>
<p>
•	Salón de usos múltiples
</p>
<p>
•	Tirolesa
</p>
<p>
•	Foto al aire libre
</p>


<p>
Asimismo, el gran espacio del parque podrá ser aprovechado para 
presentar eventos como exposiciones, ceremonias, ferias, entre otros.
</p>

<p>
Este nuevo parque se ubica sobre el Camino Al Cerro El Pino, en 
la colonia Lomas de San Isidro, en Los Reyes. Se encuentra bastante 
cerca de la CDMX, por lo que si vives por esta zona puedes llegar
 fácil y rápido.
</p>
<ul>
<li><a href="https://www.google.com/maps/place/Parque+de+la+Ciencia+La+Paz/@19.3522762,-98.9434615,17z/data=!3m1!4b1!4m6!3m5!1s0x85d1e39e43e6ec7b:0x53956574c7352fa0!8m2!3d19.3522762!4d-98.9408866!16s%2Fg%2F11twdwzp_s?entry=ttu&g_ep=EgoyMDI1MDYxMS4wIKXMDSoASAFQAw%3D%3D">Ubicacion<a></li>
<li><a href="https://www.dondeir.com/ciudad/conoce-el-parque-de-la-ciencia-la-paz-tiene-tirolesa-go-karts-y-mirador/2023/09/">mas informacion<a></li>
</ul>
<a href="indice.php" class="boton">regresar al inicio</a>

</body>
</html>